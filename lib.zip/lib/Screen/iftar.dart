import 'package:flutter/material.dart';

class Iftar extends StatelessWidget {
  const Iftar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Iftar"),
      ),
      body: Center(
        child: Text("This is the Iftar page"),
      ),
    );
  }
}
