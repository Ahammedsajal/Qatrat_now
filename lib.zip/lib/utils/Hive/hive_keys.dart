class HiveKeys {
  static String userDetailsBox = "user_details";
  static String jwtToken = "jwt_token";
}
