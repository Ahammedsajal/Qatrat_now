class Platform {
  static const bool isAndroid = false;
  static const bool isIOS = false;
}
